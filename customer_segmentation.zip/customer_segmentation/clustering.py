import pandas as pd
import numpy as np
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.decomposition import PCA

def calculate_elbow_and_silhouette(scaled_df, max_k=10):
    """Calculates Inertia and Silhouette scores for K-Means."""
    # k can never exceed n_samples - 1, otherwise KMeans/silhouette_score error out
    max_k = min(max_k, len(scaled_df) - 1)
    k_values = range(2, max_k + 1)
    inertias, sil_scores = [], []
    
    for k in k_values:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(scaled_df)
        inertias.append(kmeans.inertia_)
        sil_scores.append(silhouette_score(scaled_df, labels))
        
    best_k_sil = k_values[np.argmax(sil_scores)] if sil_scores else 2
    return list(k_values), inertias, sil_scores, best_k_sil

def apply_pca(scaled_df, n_components=3):
    """Reduces dimensions for visualization.

    Automatically caps n_components to the number of available
    features/samples, so PCA never raises:
    'ValueError: n_components=X must be between 0 and min(n_samples, n_features)'
    """
    max_components = min(scaled_df.shape[0], scaled_df.shape[1])
    n_components = max(1, min(n_components, max_components))
    pca = PCA(n_components=n_components, random_state=42)
    components = pca.fit_transform(scaled_df)
    cols = [f'PCA_{i+1}' for i in range(n_components)]
    return pd.DataFrame(components, columns=cols, index=scaled_df.index)

def train_all_algorithms(df, scaled_df, k):
    """Trains KMeans, Hierarchical, and GMM, compares metrics."""
    results = {}
    
    # 1. KMeans
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km_labels = km.fit_predict(scaled_df)
    results['K-Means'] = evaluate_model(scaled_df, km_labels, km)
    
    # 2. Hierarchical
    hc = AgglomerativeClustering(n_clusters=k)
    hc_labels = hc.fit_predict(scaled_df)
    results['Hierarchical'] = evaluate_model(scaled_df, hc_labels, hc)
    
    # 3. GMM
    gmm = GaussianMixture(n_components=k, random_state=42)
    gmm_labels = gmm.fit_predict(scaled_df)
    results['GMM'] = evaluate_model(scaled_df, gmm_labels, gmm)
    
    # Best Model Logic (Based on Silhouette)
    best_algo = max(results, key=lambda x: results[x]['Silhouette'])
    
    # Append best labels to DF
    df_clustered = df.copy()
    df_clustered['Cluster'] = results[best_algo]['Labels']
    
    return df_clustered, results, best_algo

def evaluate_model(data, labels, model_obj):
    """Calculates clustering validation metrics."""
    if len(set(labels)) > 1:
        sil = silhouette_score(data, labels)
        db = davies_bouldin_score(data, labels)
        ch = calinski_harabasz_score(data, labels)
    else:
        sil, db, ch = 0, 0, 0
    return {'Silhouette': sil, 'Davies-Bouldin': db, 'Calinski-Harabasz': ch, 'Labels': labels, 'Model': model_obj}

def generate_personas(df_clustered, features):
    """Generates Personas, ROI and Recommendations."""
    insights = {}
    overall_means = df_clustered[features].mean()
    
    for c_id in sorted(df_clustered['Cluster'].unique()):
        cluster_data = df_clustered[df_clustered['Cluster'] == c_id]
        means = cluster_data[features].mean()
        
        # Advanced Persona Logic
        persona, behavior, impact, channel = "Standard User", "Average metrics", "Medium", "Email"
        recs = ["Standard marketing", "Monthly newsletter"]
        
        has_inc = any('income' in f.lower() for f in features)
        has_spd = any('score' in f.lower() or 'spending' in f.lower() for f in features)
        
        if has_inc and has_spd:
            inc_col = [f for f in features if 'income' in f.lower()][0]
            spd_col = [f for f in features if 'score' in f.lower() or 'spending' in f.lower()][0]
            
            if means[inc_col] > overall_means[inc_col] and means[spd_col] > overall_means[spd_col]:
                persona, impact, channel = "🏆 Champions", "High", "Direct Manager / Premium App"
                behavior = "High income, high spending. Extremely valuable and loyal."
                recs = ["Exclusive VIP offers", "Early access to new products", "Loyalty rewards"]
            elif means[inc_col] > overall_means[inc_col] and means[spd_col] <= overall_means[spd_col]:
                persona, impact, channel = "🎯 Potential Targets", "Medium-High", "Targeted Email / Social Media"
                behavior = "High income but low spending. Need a push to buy."
                recs = ["Personalized discounts", "Retargeting ads", "Product recommendations"]
            elif means[inc_col] <= overall_means[inc_col] and means[spd_col] > overall_means[spd_col]:
                persona, impact, channel = "🔥 Careless Spenders", "Medium", "SMS / Push Notifications"
                behavior = "Low income but high spending. Impulse buyers."
                recs = ["Limited-time flash sales", "Value combo deals", "Affordable premium lines"]
            else:
                persona, impact, channel = "🛡️ Budget Conscious", "Low", "Social Media / Flyers"
                behavior = "Low income, low spending. Very careful with money."
                recs = ["Entry-level products", "Clearance sales", "Cost-effective marketing"]
        else:
            persona = f"Segment {c_id}"
            
        insights[c_id] = {
            'Cluster Name': f"Cluster {c_id}",
            'Persona': persona,
            'Count': len(cluster_data),
            'Percent': (len(cluster_data) / len(df_clustered)) * 100,
            'Behavior': behavior,
            'Traits': [f"Avg {f}: {means[f]:.1f}" for f in features[:3]],
            'Impact': impact,
            'Channel': channel,
            'Recommendations': recs
        }
    return insights

def predict_new_customer(model, scaler, input_data, features):
    """Scales user input and predicts cluster using KMeans."""
    input_df = pd.DataFrame([input_data], columns=features)
    scaled_input = scaler.transform(input_df)
    cluster = model.predict(scaled_input)[0]
    return cluster
