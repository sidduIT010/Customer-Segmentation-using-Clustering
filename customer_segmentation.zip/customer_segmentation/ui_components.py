"""
ui_components.py   ⭐ FRONTEND FILE ⭐  (this file was redesigned)
----------------------------------------------------------------------
Purpose: small, reusable pieces of UI (a page header, a stat card, a
persona card, colored messages) so main.py stays clean and every page
looks consistent. Kept deliberately SIMPLE: one clean light theme,
plain cards, no extra JavaScript.
"""

import streamlit as st


def load_css():
    """Injects one simple, consistent stylesheet for the whole app.
    Called once at startup by main.py."""
    st.markdown("""
        <style>
        .block-container { padding-top: 2rem; }
        .card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            margin-bottom: 16px;
            border-left: 5px solid #2563eb;
        }
        .kpi-title { font-size: 13px; color: #6b7280; font-weight: 600; text-transform: uppercase; }
        .kpi-value { font-size: 30px; color: #2563eb; font-weight: 800; }
        </style>
    """, unsafe_allow_html=True)


def render_header(title, subtitle):
    """Big title + grey subtitle shown at the top of every page, so the
    user always knows which page they are on and what it's for."""
    st.markdown(f"## {title}")
    st.caption(subtitle)
    st.divider()


def render_simple_explainer(text):
    """NEW: a collapsible 'explain it like I'm new to ML' box, shown at
    the top of every page. Directly answers 'what does this page mean
    and why does it exist' in plain, non-technical language."""
    with st.expander("💡 In Simple Words — what does this page do?", expanded=False):
        st.markdown(text)


def render_progress_checklist(progress: dict):
    """NEW: shown in the sidebar. Ticks off each major milestone as the
    user completes it, so the overall project flow (and how far along
    they are) is visible at a glance."""
    st.caption("Your progress")
    for label, done in progress.items():
        st.markdown(f"{'✅' if done else '⬜'} {label}")


def render_kpi_card(title, value, icon="📊"):
    """A single number-highlight box (e.g. 'Total Rows: 200').
    Used on the Dashboard to summarize the dataset at a glance."""
    st.markdown(f"""
        <div class="card" style="border-left-color:#0891b2;">
            <div class="kpi-title">{icon} {title}</div>
            <div class="kpi-value">{value}</div>
        </div>
    """, unsafe_allow_html=True)


def render_persona_card(persona_name, cluster_name, count, percent, behavior, traits):
    """Describes one customer segment in plain English — who they are
    and how they behave. Used on the Business Insights page."""
    traits_html = "".join(f"<li>{t}</li>" for t in traits)
    st.markdown(f"""
        <div class="card" style="border-left-color:#7c3aed;">
            <h4 style="margin-bottom:0;color:#7c3aed;">{persona_name}</h4>
            <p style="color:#6b7280;font-size:13px;">{cluster_name} &nbsp;|&nbsp; {count} customers ({percent:.1f}%)</p>
            <p><strong>Behavior:</strong> {behavior}</p>
            <p><strong>Key Traits:</strong></p>
            <ul>{traits_html}</ul>
        </div>
    """, unsafe_allow_html=True)


def render_roi_card(persona, recommendations, impact, channel):
    """Business action suggestions for one segment — what marketing
    action to take and how much revenue impact to expect. Sits next to
    each persona card on the Business Insights page."""
    color = "#16a34a" if impact == "High" else "#d97706" if "Medium" in impact else "#0891b2"
    recs_html = "".join(f"<li>{r}</li>" for r in recommendations)
    st.markdown(f"""
        <div class="card" style="border-left-color:{color};">
            <h5>{persona} — Suggested Strategy</h5>
            <p><strong>Best Channel:</strong> {channel}</p>
            <p><strong>Expected Revenue Impact:</strong> <span style="color:{color};font-weight:700;">{impact}</span></p>
            <ul>{recs_html}</ul>
        </div>
    """, unsafe_allow_html=True)


def show_error(message):
    st.error(f"⚠️ {message}")


def show_success(message):
    st.success(f"✅ {message}")


def show_info(message):
    st.info(f"ℹ️ {message}")
