import sqlite3
import bcrypt
import re
from datetime import datetime

DB_FILE = "customer_segmentation.db"

def initialize_database():
    """Creates the necessary tables including advanced fields."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_login TEXT,
            is_admin BOOLEAN DEFAULT 0
        )
    ''')
    conn.commit()
    conn.close()

def validate_password_strength(password):
    """Validates password: min 8 chars, 1 uppercase, 1 lowercase, 1 number."""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long."
    if not re.search(r"[a-z]", password):
        return False, "Password must contain at least one lowercase letter."
    if not re.search(r"[A-Z]", password):
        return False, "Password must contain at least one uppercase letter."
    if not re.search(r"[0-9]", password):
        return False, "Password must contain at least one number."
    return True, "Valid password."

def hash_password(password):
    """Hashes a password securely using bcrypt."""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(stored_password_hash, provided_password):
    """Verifies a provided password against the bcrypt hash."""
    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_password_hash.encode('utf-8'))

def user_exists(username, email):
    """Checks for duplicate username or email."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? OR email = ?", (username, email))
    user = cursor.fetchone()
    conn.close()
    return user is not None

def create_user(full_name, email, username, password):
    """Creates a new user securely."""
    is_valid, msg = validate_password_strength(password)
    if not is_valid:
        return False, msg
    if user_exists(username, email):
        return False, "Username or Email already exists!"
    
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    password_hash = hash_password(password)
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    try:
        cursor.execute('''
            INSERT INTO users (full_name, email, username, password_hash, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (full_name, email, username, password_hash, created_at))
        conn.commit()
        success = True
        msg = "Account created successfully. Please login."
    except sqlite3.Error as e:
        success = False
        msg = f"Database error: {e}"
    finally:
        conn.close()
        
    return success, msg

def authenticate_user(identifier, password):
    """Authenticates user and updates last_login."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, full_name, username, email, password_hash, is_admin FROM users 
        WHERE username = ? OR email = ?
    ''', (identifier, identifier))
    
    user = cursor.fetchone()
    
    if user and verify_password(user[4], password):
        # Update last login
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("UPDATE users SET last_login = ? WHERE id = ?", (now, user[0]))
        conn.commit()
        conn.close()
        
        return True, {
            "id": user[0], 
            "full_name": user[1], 
            "username": user[2], 
            "email": user[3],
            "is_admin": bool(user[5])
        }
        
    conn.close()
    return False, None
