"""
main.py   ⭐ FRONTEND FILE ⭐  (this file was redesigned)
================================================================
WHAT THIS PROJECT DOES (read this first)
----------------------------------------------------------------
"Customer Segmentation using Clustering" takes a spreadsheet of
customers (Age, Income, Spending Score...) and uses unsupervised
Machine Learning to automatically split them into groups ("segments")
of similar customers — WITHOUT anyone telling the computer what the
groups should be. A business can then treat each group differently
(e.g. send VIP offers to big spenders, discounts to price-sensitive
customers) instead of marketing to everyone the same way.

WHY EACH STEP EXISTS (the app is one straight workflow, top to bottom)
  1. Login / Sign Up      -> only real users can use the dashboard
  2. Dashboard             -> load data, see a quick data-quality check
  3. Explore Data (EDA)    -> look at the data visually before touching it
  4. Preprocess Data       -> clean + scale data (ML needs clean numbers)
  5. Find Best K           -> decide how many customer groups to create
  6. Train Models          -> run the actual clustering (the ML step)
  7. View Segments         -> see the groups on a chart
  8. Business Insights     -> turn groups into plain-English personas
  9. Predict New Customer  -> classify one new customer instantly
 10. About                 -> this explanation, inside the app too

Every st.button below has a `help="..."` tooltip — hover over any
button in the app to see why it's there.
"""

import streamlit as st
import pandas as pd
import io
import plotly.express as px
import plotly.graph_objects as go

from database import initialize_database, create_user, authenticate_user
from ui_components import (load_css, render_header, render_kpi_card, render_simple_explainer,
                            render_progress_checklist, render_persona_card, render_roi_card,
                            show_error, show_success)
from data_preprocessing import (load_data, calculate_data_quality, get_numeric_features,
                                 preprocess_data, scale_features)
from clustering import (calculate_elbow_and_silhouette, apply_pca, train_all_algorithms,
                         generate_personas, predict_new_customer)

# ----------------------------------------------------------------
# PAGE SETUP — runs once when the app starts
# ----------------------------------------------------------------
st.set_page_config(page_title="Customer Segmentation", page_icon="🧩", layout="wide")
initialize_database()
load_css()

STEPS = [
    "1. Dashboard", "2. Explore Data", "3. Preprocess Data", "4. Find Best K",
    "5. Train Models", "6. View Segments", "7. Business Insights",
    "8. Predict Customer", "9. About",
]

# NEW: one plain-language sentence per page, shown in an expander so
# anyone (even with zero ML background) can understand *why* the page
# exists, without reading code.
SIMPLE_EXPLANATIONS = {
    "1. Dashboard": "This is just the data loading screen. It shows how many customers "
                    "you have and a rough 'is this data clean?' score. Nothing is analyzed yet.",
    "2. Explore Data": "Before we touch the data with ML, we look at it visually — like flipping "
                        "through photos before sorting them into albums.",
    "3. Preprocess Data": "Real data has gaps and messy values. This page fixes those gaps and "
                           "puts every column on the same numeric scale, so the model treats "
                           "Income and Spending Score fairly (not letting big numbers dominate).",
    "4. Find Best K": "'K' just means 'how many customer groups do we want?'. This page tries "
                       "a few different group-counts and tells you which one works best — you "
                       "don't have to guess.",
    "5. Train Models": "This is the actual Machine Learning step. Three different grouping "
                        "algorithms look at your customers and sort them into K groups, purely "
                        "from the numbers — nobody tells them the groups in advance.",
    "6. View Segments": "A picture of the groups the model created. Customers plotted close "
                         "together on the chart are similar to each other.",
    "7. Business Insights": "Turns 'Cluster 0, Cluster 1...' into plain-English customer types "
                             "(e.g. 'Champions', 'Budget Conscious') with marketing suggestions "
                             "for each, and lets you export the results.",
    "8. Predict Customer": "Type in details for one brand-new customer, and the trained model "
                            "instantly tells you which existing group they'd most likely belong to.",
    "9. About": "A summary of the whole project and the ML techniques used, in one place.",
}

# Session-state keys that mark each milestone as "done", shown as a
# checklist in the sidebar so the overall workflow is easy to follow.
PROGRESS_MILESTONES = {
    "Data preprocessed": "scaled_df",
    "Models trained": "df_clustered",
    "Insights generated": "insights",
}

if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = STEPS[0]
if 'custom_file' not in st.session_state:
    st.session_state.custom_file = None


# ==================================================================
# LOGIN / SIGN UP SCREEN
# Why: keeps the dashboard private to registered users.
# ==================================================================
def render_auth():
    render_header("🧩 Customer Segmentation", "Log in or create an account to open the dashboard.")

    c1, c2, c3 = st.columns([1, 1.4, 1])
    with c2:
        tab_login, tab_signup = st.tabs(["Login", "Sign Up"])

        with tab_login:
            l_id = st.text_input("Username or Email")
            l_pwd = st.text_input("Password", type="password")
            if st.button("Login", type="primary", width='stretch',
                         help="Checks your username/email and password against the account database."):
                success, user = authenticate_user(l_id.strip(), l_pwd)
                if success:
                    st.session_state.logged_in = True
                    st.session_state.user_info = user
                    st.rerun()
                else:
                    show_error("Invalid username/email or password.")

        with tab_signup:
            st.caption("Password needs: 8+ characters, 1 uppercase, 1 lowercase, 1 number.")
            r_name = st.text_input("Full Name")
            r_email = st.text_input("Email")
            r_user = st.text_input("Username")
            r_pwd = st.text_input("Password", type="password", key="reg_p")
            r_pwd2 = st.text_input("Confirm Password", type="password", key="reg_p2")
            if st.button("Create Account", type="primary", width='stretch',
                         help="Validates your details and saves a new account so you can log in."):
                if r_pwd != r_pwd2:
                    show_error("Passwords do not match.")
                else:
                    success, msg = create_user(r_name, r_email, r_user, r_pwd)
                    show_success(msg) if success else show_error(msg)


# ==================================================================
# MAIN APP (only reachable after login)
# ==================================================================
def main():
    if not st.session_state.logged_in:
        render_auth()
        return

    # ---------------- SIDEBAR: step-by-step navigation ----------------
    with st.sidebar:
        st.markdown(f"### 👤 {st.session_state.user_info['full_name']}")
        st.caption("Follow the steps below in order — each one builds on the last.")
        st.divider()

        for step in STEPS:
            is_current = st.session_state.current_page == step
            if st.button(step, width='stretch', type="primary" if is_current else "secondary",
                         help=f"Go to: {step}"):
                st.session_state.current_page = step
                st.rerun()

        st.divider()
        progress = {label: (key in st.session_state) for label, key in PROGRESS_MILESTONES.items()}
        render_progress_checklist(progress)

        st.divider()
        if st.button("🔄 Start Over", width='stretch',
                      help="Clears your loaded data, cleaning settings, and trained models — "
                           "so you can restart the workflow from Step 1 without logging out."):
            keep = {'logged_in', 'user_info', 'current_page'}
            for key in list(st.session_state.keys()):
                if key not in keep:
                    del st.session_state[key]
            st.session_state.current_page = STEPS[0]
            st.rerun()

        if st.button("🚪 Logout", width='stretch', help="Ends your session and returns to the Login screen."):
            st.session_state.clear()
            st.rerun()

    page = st.session_state.current_page

    # ---------------- 1. DASHBOARD ----------------
    if page == "1. Dashboard":
        render_header("Dashboard", "Load your data here first. Everything else in the app uses this data.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["1. Dashboard"])

        st.file_uploader(
            "Upload your own CSV (optional)", type=['csv'], key="uploader",
            help="Optional: use your own customer data instead of the sample dataset that ships with the project.",
        )
        if st.session_state.uploader is not None:
            st.session_state.custom_file = st.session_state.uploader

        df, err = load_data(st.session_state.custom_file)
        if err:
            show_error(err)
            return

        dq = calculate_data_quality(df)
        c1, c2, c3 = st.columns(3)
        with c1:
            render_kpi_card("Total Customers", len(df), "👥")
        with c2:
            render_kpi_card("Total Columns", len(df.columns), "📌")
        with c3:
            render_kpi_card("Data Quality Score", f"{dq}/100", "⭐")

        st.markdown("##### Preview")
        st.dataframe(df.head(10), width='stretch')

        st.markdown("##### Next Step")
        if st.button("➡️ Go to Explore Data", type="primary",
                      help="Move to Step 2: look at the data visually before cleaning it."):
            st.session_state.current_page = "2. Explore Data"
            st.rerun()

    # ---------------- 2. EXPLORE DATA (EDA) ----------------
    elif page == "2. Explore Data":
        df, err = load_data(st.session_state.custom_file)
        if err:
            show_error(err)
            return
        render_header("Explore Data (EDA)", "Look for patterns before running any Machine Learning.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["2. Explore Data"])

        num_cols = get_numeric_features(df)
        if len(num_cols) < 2:
            show_error("Need at least 2 numeric columns to explore. Upload a different dataset.")
            return

        c1, c2 = st.columns(2)
        with c1:
            f1 = st.selectbox("Column to see the distribution of", num_cols,
                               help="Shows how one column's values are spread out (a histogram).")
            st.plotly_chart(px.histogram(df, x=f1, marginal="box", title=f"Distribution of {f1}"),
                             width='stretch')
        with c2:
            st.markdown("**Correlation Heatmap**")
            st.caption("Shows which columns move together (e.g. does higher income mean higher spending?).")
            st.plotly_chart(px.imshow(df[num_cols].corr(), text_auto=True, color_continuous_scale='Blues'),
                             width='stretch')

        st.markdown("##### Next Step")
        if st.button("➡️ Go to Preprocess Data", type="primary",
                      help="Move to Step 3: clean and scale the data so the ML model can use it."):
            st.session_state.current_page = "3. Preprocess Data"
            st.rerun()

    # ---------------- 3. PREPROCESS DATA ----------------
    elif page == "3. Preprocess Data":
        df, err = load_data(st.session_state.custom_file)
        if err:
            show_error(err)
            return
        render_header("Preprocess Data", "Clean the data and pick which columns the model should learn from.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["3. Preprocess Data"])

        c1, c2, c3 = st.columns(3)
        miss_m = c1.selectbox("Fill missing values with", ["Median", "Mean", "Drop rows"],
                               help="How to handle empty cells. Median is safest against extreme values.")
        out_m = c2.selectbox("Handle outliers", ["Keep", "Cap", "Remove"],
                              help="Outliers are unusually extreme values. Capping limits their influence.")
        scale_m = c3.selectbox("Scaling method", ["StandardScaler", "MinMaxScaler"],
                                help="Puts all chosen columns on the same numeric scale so one column can't dominate.")

        num_cols = get_numeric_features(df)
        sel_features = st.multiselect(
            "Features for the ML model (choose at least 2)", num_cols,
            default=num_cols[-2:] if len(num_cols) >= 2 else num_cols,
            help="These are the columns the clustering algorithm will actually use to group customers.",
        )

        if st.button("🧹 Clean & Scale Data", type="primary",
                      help="Runs the cleaning pipeline above and prepares the data for clustering."):
            if len(sel_features) < 2:
                show_error("Select at least 2 features.")
            else:
                miss_key = {"Median": "Median", "Mean": "Mean", "Drop rows": "Drop"}[miss_m]
                clean_df = preprocess_data(df, miss_key, True, out_m, num_cols)
                scaled_df, scaler = scale_features(clean_df, sel_features, scale_m)

                st.session_state.clean_df = clean_df
                st.session_state.scaled_df = scaled_df
                st.session_state.scaler = scaler
                st.session_state.sel_features = sel_features
                show_success("Data cleaned and scaled. You can move to the next step.")

        if 'scaled_df' in st.session_state:
            st.markdown("##### Preview of scaled data")
            st.dataframe(st.session_state.scaled_df.head(), width='stretch')
            st.markdown("##### Next Step")
            if st.button("➡️ Go to Find Best K", type="primary",
                          help="Move to Step 4: decide how many customer groups to create."):
                st.session_state.current_page = "4. Find Best K"
                st.rerun()

    # ---------------- 4. FIND BEST K ----------------
    elif page == "4. Find Best K":
        if 'scaled_df' not in st.session_state:
            show_error("Please complete Step 3: Preprocess Data first.")
            return
        render_header("Find Best K", "K = how many customer groups to create. This step suggests a good number.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["4. Find Best K"])

        k_val, inertias, sils, best_k = calculate_elbow_and_silhouette(st.session_state.scaled_df)

        c1, c2 = st.columns(2)
        with c1:
            st.caption("Elbow Curve — look for where the line bends (the 'elbow').")
            fig1 = px.line(x=k_val, y=inertias, markers=True, title="Elbow Curve (Inertia)")
            st.plotly_chart(fig1, width='stretch')
        with c2:
            st.caption("Silhouette Score — higher is better cluster separation.")
            fig2 = px.line(x=k_val, y=sils, markers=True, title="Silhouette Score")
            fig2.add_vline(x=best_k, line_dash="dash", line_color="black")
            st.plotly_chart(fig2, width='stretch')

        st.info(f"💡 Recommended number of clusters (K): **{best_k}**")

        st.markdown("##### Next Step")
        if st.button("➡️ Go to Train Models", type="primary",
                      help="Move to Step 5: actually train the clustering algorithms."):
            st.session_state.current_page = "5. Train Models"
            st.rerun()

    # ---------------- 5. TRAIN MODELS ----------------
    elif page == "5. Train Models":
        if 'scaled_df' not in st.session_state:
            show_error("Please complete Step 3: Preprocess Data first.")
            return
        render_header("Train Models", "This is the actual Machine Learning step: grouping customers.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["5. Train Models"])

        k_user = st.slider("Number of clusters (K)", 2, 10, 5,
                            help="How many customer groups to create. Use the number suggested in Step 4, or try your own.")

        if st.button("🧠 Train All Algorithms", type="primary",
                      help="Trains K-Means, Hierarchical, and GMM clustering, then picks the best one by score."):
            with st.spinner("Training models..."):
                df_clustered, results, best = train_all_algorithms(
                    st.session_state.clean_df, st.session_state.scaled_df, k_user
                )
                st.session_state.df_clustered = df_clustered
                st.session_state.algo_results = results
                st.session_state.best_algo = best
                st.session_state.kmeans_model = results['K-Means']['Model']
            show_success(f"Training complete. Best algorithm: {best}")

        if 'algo_results' in st.session_state:
            st.markdown("##### Model Comparison")
            st.caption("Silhouette: higher is better. Davies-Bouldin: lower is better. Calinski-Harabasz: higher is better.")
            metrics_df = pd.DataFrame({
                "Algorithm": list(st.session_state.algo_results.keys()),
                "Silhouette Score": [st.session_state.algo_results[a]['Silhouette'] for a in st.session_state.algo_results],
                "Davies-Bouldin": [st.session_state.algo_results[a]['Davies-Bouldin'] for a in st.session_state.algo_results],
                "Calinski-Harabasz": [st.session_state.algo_results[a]['Calinski-Harabasz'] for a in st.session_state.algo_results],
            })
            st.dataframe(metrics_df.style.highlight_max(subset=['Silhouette Score'], color='lightgreen'),
                         width='stretch')

            st.markdown("##### Next Step")
            if st.button("➡️ Go to View Segments", type="primary",
                          help="Move to Step 6: see the customer groups drawn on a chart."):
                st.session_state.current_page = "6. View Segments"
                st.rerun()

    # ---------------- 6. VIEW SEGMENTS ----------------
    elif page == "6. View Segments":
        if 'df_clustered' not in st.session_state:
            show_error("Please complete Step 5: Train Models first.")
            return
        render_header("View Segments", "See the groups the model created, plotted on a chart.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["6. View Segments"])

        df_c = st.session_state.df_clustered.copy()
        feats = st.session_state.sel_features
        df_c['Cluster_Str'] = df_c['Cluster'].astype(str)

        view_type = st.radio("Chart type", ["2D Scatter", "3D PCA Scatter"], horizontal=True,
                              help="3D PCA compresses many features into 3 dimensions purely for visualization.")

        if view_type == "2D Scatter":
            fig = px.scatter(df_c, x=feats[0], y=feats[1], color='Cluster_Str', title="Customer Segments (2D)")
            st.plotly_chart(fig, width='stretch')
        else:
            n_comp = min(3, len(feats), st.session_state.scaled_df.shape[0])
            pca_df = apply_pca(st.session_state.scaled_df, n_comp)
            pca_df['Cluster'] = df_c['Cluster_Str']
            if n_comp >= 3:
                fig = px.scatter_3d(pca_df, x='PCA_1', y='PCA_2', z='PCA_3', color='Cluster',
                                     title="Customer Segments (3D PCA)")
            elif n_comp == 2:
                st.warning("Only 2 dimensions available — showing a 2D projection instead of 3D.")
                fig = px.scatter(pca_df, x='PCA_1', y='PCA_2', color='Cluster', title="Customer Segments (2D PCA)")
            else:
                fig = None
                st.warning("Not enough data for a PCA projection.")
            if fig is not None:
                st.plotly_chart(fig, width='stretch')

        st.markdown("##### How Many Customers Are In Each Segment")
        size_df = df_c['Cluster_Str'].value_counts().reset_index()
        size_df.columns = ['Cluster', 'Customers']
        st.plotly_chart(px.bar(size_df, x='Cluster', y='Customers', color='Cluster',
                                title="Segment Sizes"), width='stretch')

        st.markdown("##### Average Feature Profile per Segment (Radar Chart)")
        avg_df = df_c.groupby('Cluster_Str')[feats].mean().reset_index()
        fig_radar = go.Figure()
        for _, row in avg_df.iterrows():
            fig_radar.add_trace(go.Scatterpolar(r=row[feats].values, theta=feats, fill='toself',
                                                  name=f"Cluster {row['Cluster_Str']}"))
        st.plotly_chart(fig_radar, width='stretch')

        st.markdown("##### Next Step")
        if st.button("➡️ Go to Business Insights", type="primary",
                      help="Move to Step 7: turn these clusters into plain-English customer personas."):
            st.session_state.current_page = "7. Business Insights"
            st.rerun()

    # ---------------- 7. BUSINESS INSIGHTS ----------------
    elif page == "7. Business Insights":
        if 'df_clustered' not in st.session_state:
            show_error("Please complete Step 5: Train Models first.")
            return
        render_header("Business Insights", "What each segment means for the business, and how to export results.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["7. Business Insights"])

        insights = generate_personas(st.session_state.df_clustered, st.session_state.sel_features)
        st.session_state.insights = insights

        for c_id, info in insights.items():
            c1, c2 = st.columns(2)
            with c1:
                render_persona_card(info['Persona'], info['Cluster Name'], info['Count'],
                                     info['Percent'], info['Behavior'], info['Traits'])
            with c2:
                render_roi_card(info['Persona'], info['Recommendations'], info['Impact'], info['Channel'])

        st.markdown("##### Export Results")
        ex1, ex2 = st.columns(2)

        csv_data = st.session_state.df_clustered.to_csv(index=False).encode('utf-8')
        ex1.download_button("📥 Download CSV", csv_data, "customer_segments.csv", "text/csv", width='stretch',
                             help="Downloads every customer with their assigned segment as a CSV file.")

        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            st.session_state.df_clustered.to_excel(writer, index=False)
        ex2.download_button("📥 Download Excel", excel_buffer.getvalue(), "customer_segments.xlsx",
                             "application/vnd.ms-excel", width='stretch',
                             help="Same data as the CSV button, in Excel format.")

        st.markdown("##### Next Step")
        if st.button("➡️ Go to Predict Customer", type="primary",
                      help="Move to Step 8: classify a brand-new customer using the trained model."):
            st.session_state.current_page = "8. Predict Customer"
            st.rerun()

    # ---------------- 8. PREDICT CUSTOMER ----------------
    elif page == "8. Predict Customer":
        if 'kmeans_model' not in st.session_state:
            show_error("Please complete Step 5: Train Models first.")
            return
        render_header("Predict Customer", "Type in one new customer's details to see which segment they'd join.")
        render_simple_explainer(SIMPLE_EXPLANATIONS["8. Predict Customer"])

        feats = st.session_state.sel_features
        st.caption("Enter values for a new customer:")
        inputs = []
        cols = st.columns(len(feats))
        for idx, f in enumerate(feats):
            val = cols[idx].number_input(f, value=0.0, help=f"The new customer's {f} value.")
            inputs.append(val)

        if st.button("🔮 Predict Segment", type="primary",
                      help="Scales your inputs the same way the training data was scaled, then classifies this customer."):
            pred = predict_new_customer(st.session_state.kmeans_model, st.session_state.scaler, inputs, feats)
            info = st.session_state.insights[pred]
            st.success(f"This customer belongs to **Cluster {pred}**")
            render_persona_card(info['Persona'], info['Cluster Name'], 1, 100.0, info['Behavior'], info['Traits'])

    # ---------------- 9. ABOUT ----------------
    elif page == "9. About":
        render_header("About This Project", "Customer Segmentation using Clustering")
        st.markdown("""
**Main motive:** automatically split a customer base into meaningful
groups using unsupervised Machine Learning, so a business can target
each group with the right marketing strategy instead of a one-size-
fits-all approach.

**Why Machine Learning (not manual rules)?** With only 2 columns you
could split customers by hand ("high income = VIP"). But real
businesses have many columns, and the natural groupings aren't
obvious to the eye — clustering algorithms find those patterns
automatically, from the data itself.

**ML techniques used:**
- **K-Means, Hierarchical Clustering, Gaussian Mixture Model (GMM)** — three different clustering algorithms, compared automatically.
- **Elbow Method & Silhouette Score** — decide the right number of groups.
- **PCA (Principal Component Analysis)** — compress data for 3D visualization.
- **StandardScaler / MinMaxScaler** — prepare data so the model treats every feature fairly.

**App workflow:** Login → Dashboard → Explore Data → Preprocess →
Find Best K → Train Models → View Segments → Business Insights →
Predict Customer.
        """)


if __name__ == "__main__":
    main()
