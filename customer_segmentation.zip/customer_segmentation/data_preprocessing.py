import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import streamlit as st

@st.cache_data
def load_data(file_obj=None, filepath="customers.csv"):
    """Loads dataset from upload or local file."""
    try:
        if file_obj is not None:
            df = pd.read_csv(file_obj)
        else:
            df = pd.read_csv(filepath)
        if df.empty: return None, "Dataset is empty!"
        return df, None
    except Exception as e:
        return None, f"Error loading data: {str(e)}"

def calculate_data_quality(df):
    """Calculates a Data Quality Score out of 100."""
    total_cells = df.shape[0] * df.shape[1]
    missing_pct = (df.isnull().sum().sum() / total_cells) * 100
    dup_pct = (df.duplicated().sum() / df.shape[0]) * 100
    score = 100 - (missing_pct * 1.5) - (dup_pct * 1.5)
    return max(0, min(100, round(score, 1)))

def get_numeric_features(df):
    """Identifies suitable numeric columns for ML."""
    cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    return [c for c in cols if 'id' not in c.lower() and 'name' not in c.lower()]

def get_categorical_features(df):
    """Identifies categorical columns (like Gender)."""
    return df.select_dtypes(include=['object', 'category']).columns.tolist()

def handle_outliers(df, cols, method='Cap'):
    """Handles outliers using IQR method."""
    df_out = df.copy()
    for col in cols:
        Q1 = df_out[col].quantile(0.25)
        Q3 = df_out[col].quantile(0.75)
        IQR = Q3 - Q1
        lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
        
        if method == 'Remove':
            df_out = df_out[(df_out[col] >= lower) & (df_out[col] <= upper)]
        elif method == 'Cap':
            df_out[col] = np.clip(df_out[col], lower, upper)
    return df_out

def preprocess_data(df, missing_method='Median', drop_dups=True, outlier_method='Keep', num_cols=[]):
    """Full preprocessing pipeline based on user choices."""
    clean_df = df.copy()
    
    if drop_dups: clean_df = clean_df.drop_duplicates()
        
    num_features = clean_df.select_dtypes(include=['number']).columns
    cat_features = clean_df.select_dtypes(exclude=['number']).columns
    if not num_features.empty:
        if missing_method == 'Drop':
            clean_df = clean_df.dropna(subset=num_features)
        elif missing_method == 'Mean':
            clean_df[num_features] = clean_df[num_features].fillna(clean_df[num_features].mean())
        else:
            clean_df[num_features] = clean_df[num_features].fillna(clean_df[num_features].median())
            
    if not cat_features.empty:
        clean_df[cat_features] = clean_df[cat_features].fillna(clean_df[cat_features].mode().iloc[0])
    if outlier_method != 'Keep' and len(num_cols) > 0:
        clean_df = handle_outliers(clean_df, num_cols, method=outlier_method)
        
    return clean_df

def scale_features(df, features, method='StandardScaler'):
    """Scales features using selected method."""
    scaler = StandardScaler() if method == 'StandardScaler' else MinMaxScaler()
    scaled_data = scaler.fit_transform(df[features])
    scaled_df = pd.DataFrame(scaled_data, columns=features, index=df.index)
    return scaled_df, scaler
